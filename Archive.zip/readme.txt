All I did was use gcc -o smallsh smallsh.c and then run the program. No special way of compiling my program 
